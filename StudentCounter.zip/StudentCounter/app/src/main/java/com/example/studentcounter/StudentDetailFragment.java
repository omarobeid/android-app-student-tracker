package com.example.studentcounter;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


public class StudentDetailFragment extends Fragment {

    private int studentId;
    public StudentDetailFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if(savedInstanceState!=null){
            studentId = savedInstanceState.getInt("student_id");
        }

        return inflater.inflate(R.layout.fragment_student_detail, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
        View view = getView();
        ImageView student_image = view.findViewById(R.id.detail_student_image);
        TextView name = view.findViewById(R.id.detail_student_name);
        TextView sessions = view.findViewById(R.id.detail_student_sessions);
        TextView rating = view.findViewById(R.id.detail_student_rating);
        TextView chapter = view.findViewById(R.id.detail_student_chapter);
        TextView notes = view.findViewById(R.id.detail_student_notes);
        TextView age = view.findViewById(R.id.detail_student_age);

        String name_test="initial";
        try{
            SQLiteOpenHelper sqLiteOpenHelper = new StudentSQLiteOneHelper(getContext());
            SQLiteDatabase db = sqLiteOpenHelper.getWritableDatabase();
            Cursor cursor = db.query("STUDENTS",
                    new String[]{"NAME" , "AGE" , "IMAGE_RESOURCE_ID" , "SESSIONS_TAKEN" , "SESSION_NB" , "RATING" , "CHAPTER" , "NOTES" },
                    "_id=?", new String[]{Integer.toString(studentId)},
                    null,null,null);
            if(cursor.moveToFirst()){
                String name_text = cursor.getString(0);
                String age_text = cursor.getString(1);
                int imageId = cursor.getInt(2);
                String sessions_taken_text = cursor.getString(3);
                String sessions_total_text = cursor.getString(4);
                String rating_text = cursor.getString(5);
                String chapter_text = cursor.getString(6);
                String notes_text = cursor.getString(7);

                student_image.setImageResource(imageId);
                name.setText(name_text);
                age.setText(age_text);
                //continue adding
                name_test=name_text;


                cursor.close();
                db.close();
            }

        }catch (Exception e ){}

        name.setText("TESTING : "+ name_test);

    }



    @Override
    public void onDestroy() {
        super.onDestroy();
    }



    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putLong("student_id",studentId);
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
}