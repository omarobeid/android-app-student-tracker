package com.example.studentcounter;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class AddingStudentActivity extends AppCompatActivity {

    SQLiteDatabase db;
    Cursor cursor;
    private ImageView imageView;

    boolean picked=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_student);
        Button add_image_button = findViewById(R.id.add_image_buton);
        imageView = (ImageView) findViewById(R.id.student_image_input);


        EditText first_name_tx =(EditText) findViewById(R.id.first_name);
        EditText last_name_tx =(EditText) findViewById(R.id.last_name);
        EditText sessions_tx =(EditText) findViewById(R.id.sessions_paid);
        EditText rating_tx =(EditText) findViewById(R.id.rating);
        EditText chapter_start_tx =(EditText) findViewById(R.id.starting_from__chapter);
        EditText age_tx = (EditText) findViewById(R.id.age);
        EditText notes_tx = (EditText) findViewById(R.id.notes);




        //trying to store image in database
//        Bitmap b = BitmapFactory.decodeResource(getResources(), R.drawable.test);
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        b.compress(Bitmap.CompressFormat.PNG, 100, bos);
//        byte[] img = bos.toByteArray();

        //trying to store image in database




        Button add_student_button = findViewById(R.id.finsih_button_add);

        add_image_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                selectImage(imageView.getContext());


            }
        });

        add_student_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SQLiteOpenHelper sqLiteOpenHelper = new StudentSQLiteOneHelper(v.getContext());
                db= sqLiteOpenHelper.getWritableDatabase();
                StudentSQLiteOneHelper studentSQLiteOneHelper = new StudentSQLiteOneHelper(v.getContext());
                studentSQLiteOneHelper.insertStudent(db,
                        first_name_tx.getText() + " " + last_name_tx.getText(),
                        age_tx.getText()+"",
                        0,                  //fix image insertion problem
                        sessions_tx.getText()+"",
                        rating_tx.getText()+"",
                        chapter_start_tx.getText()+"",
                        notes_tx.getText()+"");
                cursor.close();
                db.close();
                // String name, int age, int image_id, int session_nb, String rating, String chapter
                //Toast.makeText(getApplicationContext(),first_name_tx.getText()+" was added.",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(v.getContext(), MainActivity.class);
                startActivity(intent);

            }
        });



    }

    private void selectImage(Context context) {
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Choose your profile picture");

        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (options[item].equals("Take Photo")) {
                    Intent takePicture = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 0);


                } else if (options[item].equals("Choose from Gallery")) {
                    Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhoto , 1);


                } else if (options[item].equals("Cancel")) {
                    dialog.dismiss();

                }
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        TextView image_text = findViewById(R.id.text_after_image);
        if (resultCode != RESULT_CANCELED) {
            switch (requestCode) {
                case 0:
                    if (resultCode == RESULT_OK && data != null) {
                        Bitmap selectedImage = (Bitmap) data.getExtras().get("data");
                        imageView.setImageBitmap(selectedImage);
                    }

                    image_text.setText("Image Added Successfully!");
                    break;
                case 1:
                    if (resultCode == RESULT_OK && data != null) {
                        Uri selectedImage = data.getData();


                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
                        if (selectedImage != null) {
                            Cursor cursor = getContentResolver().query(selectedImage,
                                    filePathColumn, null, null, null);
                            if (cursor != null) {
                                cursor.moveToFirst();

                                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                                String picturePath = cursor.getString(columnIndex);
                                imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
                                cursor.close();
                            }
                        }

                    }
                    image_text.setText("Image Added Successfully!");
                    break;
            }
        }

    }
}