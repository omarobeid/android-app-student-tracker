package com.example.studentcounter;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class FinishedCaptionImagesAdapter extends RecyclerView.Adapter<FinishedCaptionImagesAdapter.ViewHolder> {



        SQLiteDatabase db;
        Cursor cursor;
        private String[] names;
        private String[] sessions;
        private int[] imageId;
        public static int[] id_of_student;




    public FinishedCaptionImagesAdapter(int[] idOfStudent, String[] names, String[] sessions, int[] imageId) {
        id_of_student = idOfStudent;
        this.names = names;
        this.sessions = sessions;
        this.imageId = imageId;
    }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        CardView cv = (CardView) LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.studentcard, viewGroup, false);
        return new FinishedCaptionImagesAdapter.ViewHolder(cv);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CardView cardView = (CardView) holder.itemView;
        TextView student_id_given = cardView.findViewById(R.id.student_unique_id);
        ImageView imageView = cardView.findViewById(R.id.student_pic);
//        imageView.setImageResource(imageId[position]);
        TextView student_name = cardView.findViewById(R.id.student_name);
        student_name.setText(names[position]);
        TextView sessions_text = cardView.findViewById(R.id.sessions);
        sessions_text.setText(sessions[position]);
        student_id_given.setText(id_of_student[position]+"");
    }


//    @Override
//    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
//        CardView cardView = viewHolder.cardView;
//        ImageView imageView = cardView.findViewById(R.id.student_pic);
//        imageView.setImageResource(imageId[position]);
//        TextView student_name = cardView.findViewById(R.id.student_name);
//        student_name.setText(names[position]);
//        TextView sessions_text = cardView.findViewById(R.id.sessions);
//        sessions_text.setText(sessions[position]);
//    }

        @Override
        public int getItemCount() {

        return names.length;
    }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            private CardView cardView;

            public ViewHolder(@NonNull CardView cv) {
                super(cv);
                cardView = cv;

                cv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int position = getAdapterPosition();
                        int student_ID = id_of_student[position];
                    Intent intent = new Intent(v.getContext(), FinishedStudentDetailActivity.class);
                    intent.putExtra("student_id",student_ID);
                    v.getContext().startActivity(intent);
//                       Toast.makeText(v.getContext(),student_ID+"",Toast.LENGTH_SHORT).show();
                    }
                });
            }

        }


}
