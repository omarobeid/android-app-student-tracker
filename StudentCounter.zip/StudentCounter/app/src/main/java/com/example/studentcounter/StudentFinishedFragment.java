package com.example.studentcounter;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class StudentFinishedFragment extends Fragment {


    SQLiteDatabase db;
    Cursor cursor;
    public String[] names;
    public String[] sessions;
    public int[] pics;
    public int[] idOfStudent;

    public StudentFinishedFragment() {
        // Required empty public constructor
    }










    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        RecyclerView recyclerView = (RecyclerView) inflater.inflate(R.layout.fragment_student_finished, container, false);


        try {

            SQLiteOpenHelper sqLiteOpenHelper = new StudentSQLiteOneHelper(getContext());
            db= sqLiteOpenHelper.getReadableDatabase();
            cursor = db.query("FINISHEDSTUDENTS",
                    new String[]{"_id","NAME","IMAGE_RESOURCE_ID", "SESSION_NB", "SESSIONS_TAKEN"},
                    null,
                    null,null,null,null);
            idOfStudent = new int[cursor.getCount()];
            names = new String[cursor.getCount()];
            sessions = new String[cursor.getCount()];
            pics = new int[cursor.getCount()];

            if(cursor.moveToFirst()){
                for(int i=0; i<cursor.getCount();i++){
                    idOfStudent[i] = cursor.getInt(0);
                    names[i] = cursor.getString(1);
                    if(cursor.getString(4)==null){
                        sessions[i] =  "0/" + cursor.getString(3);
                    }
                    else{
                        sessions[i] = cursor.getString(4) + "/" + cursor.getString(3);
                    }

                    pics[i] = cursor.getInt(2);
                    cursor.moveToNext();


                }

                cursor.close();
                db.close();

            }
        }catch (Exception e){

        }

        FinishedCaptionImagesAdapter captionImagesAdapter = new FinishedCaptionImagesAdapter( idOfStudent, names, sessions, pics);
        recyclerView.setAdapter(captionImagesAdapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);

        return recyclerView;
    }
}