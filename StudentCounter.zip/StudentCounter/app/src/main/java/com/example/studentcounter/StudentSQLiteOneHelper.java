package com.example.studentcounter;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;

import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;

public class StudentSQLiteOneHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "students";
    private static final int DB_VERSION = 1;

    public StudentSQLiteOneHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE STUDENTS (_id INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, AGE TEXT, IMAGE_RESOURCE_ID BLOB, SESSIONS_TAKEN TEXT, SESSION_NB TEXT, RATING TEXT, CHAPTER TEXT, NOTES TEXT)");
        db.execSQL("CREATE TABLE FINISHEDSTUDENTS (_id INTEGER PRIMARY KEY, NAME TEXT, AGE TEXT, IMAGE_RESOURCE_ID BLOB, SESSIONS_TAKEN TEXT, SESSION_NB TEXT, RATING TEXT, CHAPTER TEXT, NOTES TEXT)");

        insertStudent(db,"Omar", "16", R.drawable.test, "19" , "2100", "Rooks And Bishops","no notes");
        insertStudent(db,"Omar2", "16", R.drawable.test, "19" , "2200","Rooks And Bishops","no notes");


        insertFinishedStudent(db,"Omar3", "16", R.drawable.test, "19" , "2200","Rooks And Bishops","no notes");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertStudent(SQLiteDatabase db, String name, String age, int image_id, String session_nb, String rating, String chapter, String notes){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME",name);
        contentValues.put("AGE",age);
        contentValues.put("IMAGE_RESOURCE_ID",image_id);
        contentValues.put("SESSION_NB",session_nb);
        contentValues.put("RATING", rating);
        contentValues.put("CHAPTER", chapter);
        contentValues.put("NOTES", notes);
        db.insert("STUDENTS",null, contentValues);

    }

    public void insertFinishedStudent(SQLiteDatabase db, String name, String age, int image_id, String session_nb, String rating, String chapter, String notes){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME",name);
        contentValues.put("AGE",age);
        contentValues.put("IMAGE_RESOURCE_ID",image_id);
        contentValues.put("SESSION_NB",session_nb);
        contentValues.put("RATING", rating);
        contentValues.put("CHAPTER", chapter);
        contentValues.put("NOTES", notes);
        db.insert("FINISHEDSTUDENTS",null, contentValues);

    }

    //attempt to store image

    public void insertImg(int id , Bitmap img ) {


        byte[] data = getBitmapAsByteArray(img); // this is a function

//        insertStatement_logo.bindLong(1, id);
//        insertStatement_logo.bindBlob(2, data);
//
//        insertStatement_logo.executeInsert();
//        insertStatement_logo.clearBindings() ;

    }

    public static byte[] getBitmapAsByteArray(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, outputStream);
        return outputStream.toByteArray();
    }
}
