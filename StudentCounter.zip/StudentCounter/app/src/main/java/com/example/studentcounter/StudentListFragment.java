package com.example.studentcounter;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentTransaction;
import androidx.fragment.app.ListFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.List;

public class StudentListFragment extends ListFragment {
    private StudentListInterface studentListInterface;
    private  int studentId;
    SQLiteDatabase db;
    Cursor cursor;


    public StudentListFragment() {
        // Required empty public constructor
    }







    public static StudentListFragment newInstance(String param1, String param2) {
        StudentListFragment fragment = new StudentListFragment();
        Bundle args = new Bundle();

        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            SQLiteOpenHelper sqLiteOpenHelper = new StudentSQLiteOneHelper(getContext());
            db = sqLiteOpenHelper.getReadableDatabase();
            cursor = db.query("students",
                   new String[]{"_id","NAME","AGE","SESSION_NB","IMAGE_RESOURCE_ID"},
                    null,null,null,null,null);
            CursorAdapter cursorAdapter = new SimpleCursorAdapter(getContext(),
                    android.R.layout.simple_list_item_1,
                    cursor,
                    new String[]{"NAME","AGE","SESSION_NB"},
                    new int[]{android.R.id.text1},
                    0);
//            ListView listView = getListView();
//            listView.setAdapter(cursorAdapter);
            setListAdapter(cursorAdapter);
        }catch(Exception e) {

        }




    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return super.onCreateView(inflater,container,savedInstanceState);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.studentListInterface = (StudentListInterface) context;
    }

    public void onListItemClick(@NonNull ListView l, @NonNull View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        studentListInterface.itemClicked(id);

    }



    interface StudentListInterface{
        void itemClicked(long id);
    }
}