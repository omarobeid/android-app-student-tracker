package com.example.studentcounter;

public class Student {
    private String name;
    private int age;
    private int image_id;
    private int session_nb;

    public Student(String name, int age, int image_id) {
        this.name = name;
        this.age = age;
        this.image_id = image_id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getImage_id() {
        return image_id;
    }

    public int getSession_nb() {
        return session_nb;
    }

    public void setSession_nb(int session_nb) {
        this.session_nb = session_nb;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setImage_id(int image_id) {
        this.image_id = image_id;
    }

}
