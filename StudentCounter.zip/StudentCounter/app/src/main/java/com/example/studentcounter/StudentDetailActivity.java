package com.example.studentcounter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class StudentDetailActivity extends AppCompatActivity {

    private int studentId;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail);
        Intent intent = getIntent();
         studentId = intent.getIntExtra("student_id",0);

        if(savedInstanceState!=null){
            studentId = savedInstanceState.getInt("student_id");
        }

//        Button edit_student_button = findViewById(R.id.edit_student_button);
//        edit_student_button.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                Intent sent = new Intent(v.getContext(), EditingStudentActivity.class);
//                sent.putExtra("student_id",studentId);
//                startActivity(sent);
//
//            }
//        });




    }

    @Override
    protected void onStart() {
        super.onStart();
        String sessions_taken_text;
        String sessions_total_text;

        ImageView student_image = findViewById(R.id.detail_student_image);
        TextView name = findViewById(R.id.detail_student_name);
        TextView sessions = findViewById(R.id.detail_student_sessions);
        TextView rating = findViewById(R.id.detail_student_rating);
        TextView chapter = findViewById(R.id.detail_student_chapter);
        TextView notes = findViewById(R.id.detail_student_notes);
        TextView age = findViewById(R.id.detail_student_age);


//editing button
        Button edit_student_button = findViewById(R.id.edit_student_button);
        edit_student_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent sent = new Intent(v.getContext(), EditingStudentActivity.class);

                //attempt to send picture
//                Bitmap bmp = BitmapFactory.decodeResource(getResources(), R.drawable.test);
//                ByteArrayOutputStream stream = new ByteArrayOutputStream();
//                bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
//                byte[] byteArray = stream.toByteArray();
//                sent.putExtra("imageId", byteArray);
                //attempt to send picture finished
                sent.putExtra("student_id",studentId);
                sent.putExtra("name", name.getText());
                sent.putExtra("sessions", sessions.getText());
                sent.putExtra("rating", rating.getText());
                sent.putExtra("chapter", chapter.getText());
                sent.putExtra("notes", notes.getText());
                sent.putExtra("age", age.getText());
                startActivity(sent);

            }
        });
        //end of editing button





        String name_test="initial";
        try{
            Button remove_student_button = findViewById(R.id.remove_student_button);

            Button given_student_button = findViewById(R.id.given_student_button);
            SQLiteOpenHelper sqLiteOpenHelper = new StudentSQLiteOneHelper(getBaseContext());
            SQLiteDatabase db = sqLiteOpenHelper.getWritableDatabase();
            Cursor cursor = db.query("STUDENTS",
                    new String[]{"NAME" , "AGE" , "IMAGE_RESOURCE_ID" , "SESSIONS_TAKEN" , "SESSION_NB" , "RATING" , "CHAPTER" , "NOTES" },
                    "_id=?", new String[]{Integer.toString(studentId)},
                    null,null,null);
            if(cursor.moveToFirst()){
                String name_text = cursor.getString(0);
                String age_text = cursor.getString(1);
                int imageId = cursor.getInt(2);
                sessions_taken_text = cursor.getString(3);
                sessions_total_text = cursor.getString(4);
                String rating_text = cursor.getString(5);
                String chapter_text = cursor.getString(6);
                String notes_text = cursor.getString(7);

                if(sessions_taken_text==null){
                    sessions_taken_text="0";
                }

                student_image.setImageResource(imageId);
                name.setText(name_text);
                age.setText(age_text);
                sessions.setText(sessions_taken_text+"/"+sessions_total_text);
                rating.setText(rating_text);
                chapter.setText(chapter_text);
                notes.setText(notes_text);



                //buttons functionalities

                //--remove button
                remove_student_button.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        db.delete("STUDENTS",
                               "_id=?", new String[]{Integer.toString(studentId)});
                        Intent intent = new Intent(v.getContext(), MainActivity.class);
                        v.getContext().startActivity(intent);
                    }
                });

                int finalSessions_taken_text = Integer.parseInt(sessions_taken_text);
                int finalSessions_total_text1 = Integer.parseInt(sessions_total_text);
                String finalSessions_taken_text2 = sessions_taken_text;
                //--end of remove button




                //given session button
                given_student_button.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        if(finalSessions_taken_text==finalSessions_total_text1-1){





                            ContentValues cv_2 = new ContentValues();


                            ContentValues cv_add = new ContentValues();
                            int new_sessions_total =  Integer.parseInt(sessions_total_text);


//                            cv_add.put("_id",studentId);
                            cv_add.put("NAME",name_text);
                            cv_add.put("AGE",age_text);
                            cv_add.put("IMAGE_RESOURCE_ID",0);
                            cv_add.put("SESSION_NB",new_sessions_total);
                            cv_add.put("SESSIONS_TAKEN",finalSessions_taken_text+1);
                            cv_add.put("RATING", rating_text);
                            cv_add.put("CHAPTER", chapter_text);
                            cv_add.put("NOTES", notes_text);
                            db.insert("FINISHEDSTUDENTS",null, cv_add);
                            db.delete("STUDENTS",
                                    "_id=?", new String[]{Integer.toString(studentId)});
                            Intent intent = new Intent(v.getContext(), MainActivity.class);
                            v.getContext().startActivity(intent);





                            //put this student in the finished students table
                            Toast.makeText(getApplicationContext(),"Student finished his paid sessions.",Toast.LENGTH_SHORT).show();
                            Intent back = new Intent(getBaseContext(),MainActivity.class);
                            startActivity(back);
                        }
                        else{
                            int sessions_taken_update = Integer.parseInt(finalSessions_taken_text2) +1;
                            ContentValues cv = new ContentValues();
                            cv.put("SESSIONS_TAKEN",Integer.toString(sessions_taken_update) );
                            db.update("STUDENTS",
                                    cv,
                                    "_id=?", new String[]{Integer.toString(studentId)});


                            //is finished
//                        Cursor cursor2 = db.query("STUDENTS",
//                                new String[]{"FINISHED" },
//                                "_id=?", new String[]{Integer.toString(studentId)},
//                                null,null,null);

                            //end of isFinished
                            //-- end of given button

                            Intent i = new Intent(StudentDetailActivity.this, StudentDetailActivity.class);
                            i.putExtra("student_id", studentId);
                            finish();
                            overridePendingTransition(0, 0);
                            startActivity(i);
                            overridePendingTransition(0, 0);
                        }


                    }
                });






                cursor.close();

            }

        }catch (Exception e ){}



    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }





    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);   //perhaps should delete super
        outState.putLong("student_id", studentId);
    }

    public void setStudentId(int studentId){ this.studentId = studentId;}
}


