package com.example.studentcounter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class EditingStudentActivity extends AppCompatActivity {

    private ImageView imageView;
    public int studentId;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editing_student);

        Intent intent = getIntent();
        //attempt to retrieve photo
//        Bundle extras = getIntent().getExtras();
//        byte[] byteArray = extras.getByteArray("imageId");
//        Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
//        ImageView image = (ImageView) findViewById(R.id.updated_student_image_input);
//        image.setImageBitmap(bmp);


        //end of attempt
        studentId = intent.getIntExtra("student_id",0);
        String name = intent.getStringExtra("name");
        String sessions= intent.getStringExtra("sessions");;
        String rating= intent.getStringExtra("rating");;
        String chapter= intent.getStringExtra("chapter");;
        String notes= intent.getStringExtra("notes");;
        String age= intent.getStringExtra("age");;


        Button update_image_button = findViewById(R.id.updated_image_buton);
        imageView = (ImageView) findViewById(R.id.student_image_input);


        EditText first_name_tx =(EditText) findViewById(R.id.updated_first_name);
        EditText last_name_tx =(EditText) findViewById(R.id.updated_last_name);
        EditText sessions_tx =(EditText) findViewById(R.id.updated_sessions_paid);
        EditText rating_tx =(EditText) findViewById(R.id.updated_rating);
        EditText chapter_start_tx =(EditText) findViewById(R.id.updated_starting_from__chapter);
        EditText age_tx = (EditText) findViewById(R.id.updated_age);
        EditText notes_tx = (EditText) findViewById(R.id.updated_notes);

        first_name_tx.setText(name);
        sessions_tx.setText(sessions);
        rating_tx.setText(rating);
        chapter_start_tx.setText(chapter);
        age_tx.setText(age);
        notes_tx.setText(notes);

        Button updated_student_button = findViewById(R.id.finsih_button_updated);

        update_image_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //selectImage(imageView.getContext());

            }
        });

        updated_student_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SQLiteOpenHelper sqLiteOpenHelper = new StudentSQLiteOneHelper(v.getContext());
                SQLiteDatabase db = sqLiteOpenHelper.getWritableDatabase();
                StudentSQLiteOneHelper studentSQLiteOneHelper = new StudentSQLiteOneHelper(v.getContext());
                ContentValues cv = new ContentValues();
                //NAME TEXT, AGE TEXT,
                // IMAGE_RESOURCE_ID INTEGER,
                // SESSIONS_TAKEN TEXT,
                // SESSION_NB TEXT,
                // RATING TEXT,
                // CHAPTER TEXT,
                // NOTES TEXT)


                cv.put("NAME", first_name_tx.getText()+" "+last_name_tx.getText());
                cv.put("IMAGE_RESOURCE_ID",0);
                cv.put("SESSION_NB",sessions_tx.getText()+"");
                cv.put("RATING",rating_tx.getText()+"");
                cv.put("CHAPTER",chapter_start_tx.getText()+"");
                cv.put("AGE",age_tx.getText()+"");
                cv.put("NOTES",notes_tx.getText()+"");

                db.update("STUDENTS",
                        cv,
                        "_id=?", new String[]{Integer.toString(studentId)});


                // String name, int age, int image_id, int session_nb, String rating, String chapter
                Intent intent = new Intent(v.getContext(), MainActivity.class);
                startActivity(intent);

            }
        });



    }
}